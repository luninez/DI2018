/**
 * @title Query progress-bar
 */
export declare class ProgressBarQueryExample {
}
