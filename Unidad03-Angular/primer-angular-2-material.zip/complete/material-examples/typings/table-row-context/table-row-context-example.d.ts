/**
 * @title Table showing each row context properties.
 */
export declare class TableRowContextExample {
    displayedColumns: string[];
    data: string[];
}
