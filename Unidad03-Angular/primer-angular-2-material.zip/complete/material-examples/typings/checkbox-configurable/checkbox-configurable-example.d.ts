/**
 * @title Configurable checkbox
 */
export declare class CheckboxConfigurableExample {
    checked: boolean;
    indeterminate: boolean;
    labelPosition: string;
    disabled: boolean;
}
