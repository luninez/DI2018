/**
 * @title Basic button-toggles
 */
export declare class ButtonToggleOverviewExample {
}
