import { MatDialog } from '@angular/material';
/**
 * @title Dialog elements
 */
export declare class DialogElementsExample {
    dialog: MatDialog;
    constructor(dialog: MatDialog);
    openDialog(): void;
}
export declare class DialogElementsExampleDialog {
}
