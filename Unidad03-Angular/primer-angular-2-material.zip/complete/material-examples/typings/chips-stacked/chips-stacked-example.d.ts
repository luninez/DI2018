/**
 * @title Stacked chips
 */
export declare class ChipsStackedExample {
    color: string;
    availableColors: {
        name: string;
        color: string;
    }[];
}
