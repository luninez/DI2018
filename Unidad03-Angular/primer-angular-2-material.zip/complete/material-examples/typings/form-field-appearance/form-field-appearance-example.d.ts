/** @title Form field appearance variants */
export declare class FormFieldAppearanceExample {
}
