/**
 * @title Basic Inputs
 */
export declare class InputOverviewExample {
}
