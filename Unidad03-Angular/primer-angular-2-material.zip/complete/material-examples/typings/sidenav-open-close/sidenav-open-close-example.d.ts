/** @title Sidenav open & close behavior */
export declare class SidenavOpenCloseExample {
    events: string[];
    opened: boolean;
    shouldRun: boolean;
}
