/** @title Datepicker touch UI */
export declare class DatepickerTouchExample {
}
