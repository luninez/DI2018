import { FormControl } from '@angular/forms';
/** @title Select with form field features */
export declare class SelectHintErrorExample {
    animalControl: FormControl;
    animals: {
        name: string;
        sound: string;
    }[];
}
