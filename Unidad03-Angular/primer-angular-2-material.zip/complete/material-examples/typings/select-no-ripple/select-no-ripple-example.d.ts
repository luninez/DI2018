/** @title Select with no option ripple */
export declare class SelectNoRippleExample {
}
