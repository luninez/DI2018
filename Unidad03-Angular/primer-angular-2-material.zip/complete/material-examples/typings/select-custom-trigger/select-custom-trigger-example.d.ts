import { FormControl } from '@angular/forms';
/** @title Select with custom trigger text */
export declare class SelectCustomTriggerExample {
    toppings: FormControl;
    toppingList: string[];
}
