import { FormBuilder, FormGroup } from '@angular/forms';
/** @title Form field with label */
export declare class FormFieldLabelExample {
    options: FormGroup;
    constructor(fb: FormBuilder);
}
