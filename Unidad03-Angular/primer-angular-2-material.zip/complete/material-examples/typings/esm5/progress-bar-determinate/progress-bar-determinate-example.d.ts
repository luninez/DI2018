/**
 * @title Determinate progress-bar
 */
export declare class ProgressBarDeterminateExample {
}
