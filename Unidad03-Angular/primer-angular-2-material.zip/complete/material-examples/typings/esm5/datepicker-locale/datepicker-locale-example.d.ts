import { DateAdapter } from '@angular/material/core';
/** @title Datepicker with different locale */
export declare class DatepickerLocaleExample {
    private adapter;
    constructor(adapter: DateAdapter<any>);
    french(): void;
}
