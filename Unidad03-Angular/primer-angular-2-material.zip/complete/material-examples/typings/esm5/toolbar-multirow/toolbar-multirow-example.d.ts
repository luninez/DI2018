/**
 * @title Multi-row toolbar
 */
export declare class ToolbarMultirowExample {
}
