/** @title Datepicker with min & max validation */
export declare class DatepickerMinMaxExample {
    minDate: Date;
    maxDate: Date;
}
