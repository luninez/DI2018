import { FormBuilder, FormGroup } from '@angular/forms';
/** @title Fixed sidenav */
export declare class SidenavFixedExample {
    options: FormGroup;
    constructor(fb: FormBuilder);
    shouldRun: boolean;
}
