/**
 * @title Basic icons
 */
export declare class IconOverviewExample {
}
