/**
 * @title Slider with custom thumb label formatting.
 */
export declare class SliderFormattingExample {
    formatLabel(value: number | null): string | number;
}
