/**
 * @title Basic progress-spinner
 */
export declare class ProgressSpinnerOverviewExample {
}
