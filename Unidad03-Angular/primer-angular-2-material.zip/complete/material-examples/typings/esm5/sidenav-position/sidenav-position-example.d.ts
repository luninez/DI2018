/** @title Implicit main content with two sidenavs */
export declare class SidenavPositionExample {
    shouldRun: boolean;
}
