/**
 * @title Native `<table>` that only applies the Material styles
 */
export declare class TableNativeOnlyExample {
    elements: {
        position: number;
        name: string;
        weight: number;
        symbol: string;
    }[];
}
