/**
 * @title Buffer progress-bar
 */
export declare class ProgressBarBufferExample {
}
