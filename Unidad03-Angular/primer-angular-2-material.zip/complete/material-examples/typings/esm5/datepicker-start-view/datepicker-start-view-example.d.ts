/** @title Datepicker start date */
export declare class DatepickerStartViewExample {
    startDate: Date;
}
