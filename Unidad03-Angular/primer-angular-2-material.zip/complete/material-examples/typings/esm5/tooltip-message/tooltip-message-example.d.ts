import { FormControl } from '@angular/forms';
/**
 * @title Tooltip with a changing message
 */
export declare class TooltipMessageExample {
    message: FormControl;
}
