/**
 * @title Basic chips
 */
export declare class ChipsOverviewExample {
}
