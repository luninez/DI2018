import { FormControl } from '@angular/forms';
/**
 * @title Select with custom panel styling
 */
export declare class SelectPanelClassExample {
    panelColor: FormControl;
}
