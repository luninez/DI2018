/** @title Drawer with explicit backdrop setting */
export declare class SidenavBackdropExample {
}
