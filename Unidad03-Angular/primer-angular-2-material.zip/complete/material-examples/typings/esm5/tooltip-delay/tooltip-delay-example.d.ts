import { FormControl } from '@angular/forms';
/**
 * @title Tooltip with a show and hide delay
 */
export declare class TooltipDelayExample {
    showDelay: FormControl;
    hideDelay: FormControl;
}
