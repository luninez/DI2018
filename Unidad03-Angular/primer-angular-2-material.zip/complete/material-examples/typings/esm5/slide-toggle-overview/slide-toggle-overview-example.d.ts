/**
 * @title Basic slide-toggles
 */
export declare class SlideToggleOverviewExample {
}
