/**
 * @title Basic radios
 */
export declare class RadioOverviewExample {
}
