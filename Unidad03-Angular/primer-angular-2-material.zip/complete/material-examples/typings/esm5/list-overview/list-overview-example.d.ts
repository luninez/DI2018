/**
 * @title Basic list
 */
export declare class ListOverviewExample {
}
