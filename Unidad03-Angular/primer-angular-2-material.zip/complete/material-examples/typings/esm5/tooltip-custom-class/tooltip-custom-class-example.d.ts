/**
 * @title Tooltip that can have a custom class applied.
 */
export declare class TooltipCustomClassExample {
}
