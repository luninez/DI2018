/**
 * @title Badge overview
 */
export declare class BadgeOverviewExample {
}
