import { FormControl } from '@angular/forms';
/**
 * @title Tooltip that can be disabled
 */
export declare class TooltipDisabledExample {
    disabled: FormControl;
}
