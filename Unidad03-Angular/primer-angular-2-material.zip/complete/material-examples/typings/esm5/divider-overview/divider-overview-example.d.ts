/**
 * @title Basic divider
 */
export declare class DividerOverviewExample {
}
