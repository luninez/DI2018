/**
 * @title Inputs in a form
 */
export declare class InputFormExample {
}
