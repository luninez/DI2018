import { FormControl } from '@angular/forms';
/** @title Disabled select */
export declare class SelectDisabledExample {
    disableSelect: FormControl;
}
