/**
 * @title Tooltip that can be manually shown/hidden.
 */
export declare class TooltipManualExample {
}
