/**
 * @title Input with hints
 */
export declare class InputHintExample {
}
