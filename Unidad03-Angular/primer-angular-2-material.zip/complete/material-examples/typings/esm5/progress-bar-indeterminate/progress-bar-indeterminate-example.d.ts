/**
 * @title Indeterminate progress-bar
 */
export declare class ProgressBarIndeterminateExample {
}
