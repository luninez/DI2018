import { FormControl } from '@angular/forms';
/** @title Datepicker that uses Moment.js dates */
export declare class DatepickerMomentExample {
    date: FormControl;
}
