/**
 * @title Basic checkboxes
 */
export declare class CheckboxOverviewExample {
}
