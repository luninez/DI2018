/**
 * @title List with selection
 */
export declare class ListSelectionExample {
    typesOfShoes: string[];
}
