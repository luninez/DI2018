/** @title Datepicker with custom icon */
export declare class DatepickerCustomIconExample {
}
