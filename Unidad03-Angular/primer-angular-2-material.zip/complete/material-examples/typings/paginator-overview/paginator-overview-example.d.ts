/**
 * @title Paginator
 */
export declare class PaginatorOverviewExample {
}
