import { MatAccordion } from '@angular/material';
/**
 * @title Accordion with expand/collapse all toggles
 */
export declare class ExpansionExpandCollapseAllExample {
    accordion: MatAccordion;
}
