/** @title Monitoring autofill state with cdkAutofill */
export declare class TextFieldAutofillDirectiveExample {
    firstNameAutofilled: boolean;
    lastNameAutofilled: boolean;
}
