/**
 * @title Basic grid-list
 */
export declare class GridListOverviewExample {
}
