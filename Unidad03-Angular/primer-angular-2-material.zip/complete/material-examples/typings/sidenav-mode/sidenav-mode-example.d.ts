import { FormControl } from '@angular/forms';
/** @title Sidenav with configurable mode */
export declare class SidenavModeExample {
    mode: FormControl;
    shouldRun: boolean;
}
