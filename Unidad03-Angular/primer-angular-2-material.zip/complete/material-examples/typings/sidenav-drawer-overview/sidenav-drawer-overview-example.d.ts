/** @title Basic drawer */
export declare class SidenavDrawerOverviewExample {
}
