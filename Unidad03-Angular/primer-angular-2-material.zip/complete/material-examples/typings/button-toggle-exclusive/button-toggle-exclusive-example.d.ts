/**
 * @title Exclusive selection
 */
export declare class ButtonToggleExclusiveExample {
}
