import { FormControl } from '@angular/forms';
/**
 * @title Simple autocomplete
 */
export declare class AutocompleteSimpleExample {
    myControl: FormControl;
    options: string[];
}
