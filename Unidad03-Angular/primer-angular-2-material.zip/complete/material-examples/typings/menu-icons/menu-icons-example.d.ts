/**
 * @title Menu with icons
 */
export declare class MenuIconsExample {
}
