/** @title Select with 2-way value binding */
export declare class SelectValueBindingExample {
    selected: string;
}
