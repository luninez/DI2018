/** @title Datepicker palette colors */
export declare class DatepickerColorExample {
}
