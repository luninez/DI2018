/**
 * @title Expansion panel as accordion
 */
export declare class ExpansionStepsExample {
    step: number;
    setStep(index: number): void;
    nextStep(): void;
    prevStep(): void;
}
