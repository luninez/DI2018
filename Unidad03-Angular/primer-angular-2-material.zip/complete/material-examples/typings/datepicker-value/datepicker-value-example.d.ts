import { FormControl } from '@angular/forms';
/** @title Datepicker selected value */
export declare class DatepickerValueExample {
    date: FormControl;
    serializedDate: FormControl;
}
