/**
 * @title Radios with ngModel
 */
export declare class RadioNgModelExample {
    favoriteSeason: string;
    seasons: string[];
}
