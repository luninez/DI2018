import { FormControl } from '@angular/forms';
/**
 * @title Input with error messages
 */
export declare class InputErrorsExample {
    emailFormControl: FormControl;
}
