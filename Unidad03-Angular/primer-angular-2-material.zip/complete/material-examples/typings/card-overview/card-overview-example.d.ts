/**
 * @title Basic cards
 */
export declare class CardOverviewExample {
}
