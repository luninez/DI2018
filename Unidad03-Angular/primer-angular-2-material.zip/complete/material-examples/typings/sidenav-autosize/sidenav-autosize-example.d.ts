/**
 * @title Autosize sidenav
 */
export declare class SidenavAutosizeExample {
    showFiller: boolean;
}
