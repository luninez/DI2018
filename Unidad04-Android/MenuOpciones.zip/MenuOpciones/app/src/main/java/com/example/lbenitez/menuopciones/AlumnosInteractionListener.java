package com.example.lbenitez.menuopciones;

public interface AlumnosInteractionListener {

    public void onAlumnoEditClick(long id);
    public void onAlumnoDeleteClick(long id);


}
